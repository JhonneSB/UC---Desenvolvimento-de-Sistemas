# ValidadorDeCPF
Aplicação Java desenvolvida como exercício de fixação particular. Após descobrir como funciona o algoritmo de validação de CPF, me despertou a curiosidade de tentar fazer uma aplicação que efetue tal algoritmo de maneira automática.
