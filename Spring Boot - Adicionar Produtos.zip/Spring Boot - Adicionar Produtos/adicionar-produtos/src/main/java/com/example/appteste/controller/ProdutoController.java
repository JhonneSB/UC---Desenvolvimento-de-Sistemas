package com.example.appteste.controller;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model; // Corrigido para o Model do Spring MVC
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.appteste.ApptesteApplication;
import com.example.appteste.model.Produto;

@Controller
public class ProdutoController {

    private final ApptesteApplication apptesteApplication;

    private List<Produto> produtos = new ArrayList<>();

    
    @GetMapping("/")
    public String exibirFormulario(Model model) {
        model.addAttribute("produto", new Produto());
        return "form";
    }
    @PostMapping("/adicionar")
    public String adicionarProduto(@ModelAttribute Produto produto, Model model) {
        produtos.add(produto);
        model.addAttribute("produtos", produtos);
        return "tabela";
    }
    ProdutoController(ApptesteApplication apptesteApplication) {
        this.apptesteApplication = apptesteApplication;
    }

    @GetMapping("/tabela")
    public String MostrarProduto(Model model) {
        produtos.clear();
        try(BufferedReader br = new BufferedReader(new FileReader("produtos.txt"))){
            String linha;
            while ((linha = br.readLine()) != null){
                String[] dados = linha.split(";");

                if(dados.length == 4){
                    try {
                        //parse dos valores
                        String codigo = dados[0].trim();
                        String desc = dados[1].trim();
                        int quantidade = Integer.parseInt(dados[2].trim());
                        double preco = Double.parseDouble(dados[3].trim());

                        // Criação do produto
                        Produto produto = new Produto();

                        produto.setCodigo(codigo);
                        produto.setDescricao(desc);
                        produto.setQtd(quantidade);
                        produto.setPreco(preco);

                        produtos.add(produto);
                        
                    } catch (NumberFormatException e) {
                        System.err.println("Erro de processamento...Lnha:"+linha+" - " + e.getMessage());
                        // TODO: handle exception
                    }
                }
            }
            
        }
        
            catch(Exception e){
                System.err.println("Erro de leitura de arquivos: " + e.getMessage());
            }
            model.addAttribute("produtos", produtos);

            return "tabela";

    }
}
