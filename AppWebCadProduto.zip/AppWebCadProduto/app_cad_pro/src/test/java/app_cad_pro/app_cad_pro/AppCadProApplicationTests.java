package app_cad_pro.app_cad_pro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppCadProApplicationTests {

	@Test
	void contextLoads() {
	}

}
