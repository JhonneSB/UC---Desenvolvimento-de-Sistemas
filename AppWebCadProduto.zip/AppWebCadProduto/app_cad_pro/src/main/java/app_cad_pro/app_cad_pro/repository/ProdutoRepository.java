package app_cad_pro.app_cad_pro.repository;

public interface ProdutoRepositoryy {

}
