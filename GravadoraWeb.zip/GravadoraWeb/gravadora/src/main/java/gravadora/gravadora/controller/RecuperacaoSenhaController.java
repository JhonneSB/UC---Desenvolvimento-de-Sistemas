package gravadora.gravadora.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import gravadora.gravadora.model.Usuario;
import gravadora.gravadora.repository.UsuarioRepository;
import jakarta.servlet.http.HttpServletRequest;

@Controller
public class RecuperacaoSenhaController {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @GetMapping("/esqueci-senha")
    public String exibirTelaEsqueciSenha() {
        return "esqueci_senha"; // Retorna a página onde o usuário informa o e-mail
    }

    @PostMapping("/esqueci-senha")
    public String processarEsqueciSenha(String email, Model model, HttpServletRequest request) {
        Usuario usuario = usuarioRepository.findByEmail(email);
        
        if (usuario != null) {
            request.getSession().setAttribute("emailRecuperacao", email);
            return "redirect:/trocar-senha"; // Redireciona para a tela de troca de senha
        }
        
        model.addAttribute("Erro", "E-mail não encontrado!");
        return "esqueci_senha"; // Retorna para a mesma página com a mensagem de erro
    }

    @GetMapping("/trocar-senha")
    public String exibirTelaTrocaSenha(HttpServletRequest request, Model model) {
        String email = (String) request.getSession().getAttribute("emailRecuperacao");
        
        if (email == null) {
            return "redirect:/esqueci-senha"; // Se não houver e-mail armazenado, redireciona
        }
        
        model.addAttribute("email", email);
        return "trocar_senha"; // Retorna a página de troca de senha
    }

    @PostMapping("/trocar-senha")
    public String trocarSenha(String novaSenha, HttpServletRequest request) {
        String email = (String) request.getSession().getAttribute("emailRecuperacao");
        
        if (email != null) {
            Usuario usuario = usuarioRepository.findByEmail(email);
            if (usuario != null) {
                usuario.setSenha(novaSenha);
                usuarioRepository.save(usuario);
                request.getSession().removeAttribute("emailRecuperacao"); // Remove a sessão
                return "redirect:/login"; // Redireciona para login após troca bem-sucedida
            }
        }
        
        return "redirect:/esqueci-senha"; // Se houver erro, volta para a tela inicial de recuperação
    }
}
