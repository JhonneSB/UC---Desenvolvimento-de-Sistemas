package gravadora.gravadora.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import gravadora.gravadora.model.Genero;

public interface GeneroRepository extends JpaRepository<Genero, Long>{
    Genero findByNome(String nome);  // Método para buscar artista por nome
}
