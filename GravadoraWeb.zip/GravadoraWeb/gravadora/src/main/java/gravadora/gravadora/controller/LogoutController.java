package gravadora.gravadora.controller;

import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import gravadora.gravadora.service.CookieService;

@Controller
public class LogoutController {

    @GetMapping("/logout")
    public String logout(HttpServletResponse response) {
        // Remove o cookie de autenticação
        System.out.println("Removendo cookie de autenticação...");
        CookieService.removeCookie(response, "usuarioId");

        // Redireciona para a tela de login
        return "redirect:/login";
    }
}
