package gravadora.gravadora.controller;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;
import gravadora.gravadora.service.UsuarioService;

@Controller
public class HomeController {

    @Autowired
    private UsuarioService usuarioService;  // Supondo que você tenha esse serviço para buscar o nome do usuário

    @GetMapping("/")
    public ModelAndView home(HttpServletRequest request) {
        Cookie[] cookies = request.getCookies();
        boolean usuarioLogado = false;
        String nomeUsuario = "Usuário"; // Nome padrão

        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if ("usuarioId".equals(cookie.getName())) {  // Verifica se o cookie de 'usuarioId' existe
                    usuarioLogado = true;
                    String usuarioId = cookie.getValue(); // Recupera o ID do usuário

                    // Agora, busque o nome do usuário usando o ID
                    nomeUsuario = usuarioService.buscarNomePorId(usuarioId);  // Ajuste de acordo com o seu método
                    break;
                }
            }
        }

        // Se não estiver logado, redireciona para a tela de login
        if (!usuarioLogado) {
            return new ModelAndView("redirect:/login");  // Redireciona para o login
        }

        // Passa o nome do usuário para o template
        ModelAndView modelAndView = new ModelAndView("home");
        modelAndView.addObject("username", nomeUsuario);  // Adiciona o nome do usuário ao modelo
        return modelAndView;  // Caso o usuário esteja logado, mostra a página home
    }
}
