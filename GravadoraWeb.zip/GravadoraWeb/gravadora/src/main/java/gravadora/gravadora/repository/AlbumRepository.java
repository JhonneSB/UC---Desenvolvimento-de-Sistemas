package gravadora.gravadora.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import gravadora.gravadora.model.Album;

public interface AlbumRepository extends JpaRepository<Album, Long> {
    List<Album> findByArtistaNome (String nome);
    

}

