package gravadora.gravadora.autenticator;

import gravadora.gravadora.service.CookieService;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebFilter("/*")  // Aplica o filtro em todas as rotas
public class AuthenticationFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // Inicialização do filtro (caso precise)
    }

    @Override
    public void doFilter(jakarta.servlet.ServletRequest request, jakarta.servlet.ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        // Verifica se a URL não é a de login ou de registro
        String uri = httpRequest.getRequestURI();
        if (!uri.contains("/login") && !uri.contains("/registrar")) {
            try {
                // Verifica se o cookie "usuarioId" está presente
                String usuarioId = CookieService.getCookie(httpRequest, "usuarioId");
                if (usuarioId == null) {
                    // Se o cookie não estiver presente, redireciona para a tela de login
                    System.out.println("Cookie 'usuarioId' não encontrado. Redirecionando para login...");
                    httpResponse.sendRedirect("/login");
                    return; // Não prossegue com a requisição
                }
            } catch (Exception e) {
                e.printStackTrace();
                httpResponse.sendRedirect("/login"); // Caso algo falhe, redireciona para login
                return;
            }
        }

        // Se o usuário estiver autenticado ou se a requisição for para login/registro, continue a requisição
        chain.doFilter(request, response);
    }

    @Override
    public void destroy() {
        // Finalização do filtro (caso precise)
    }
}
