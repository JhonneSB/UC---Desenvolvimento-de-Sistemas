package gravadora.gravadora.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import gravadora.gravadora.model.Artista;
import gravadora.gravadora.repository.ArtistaRepository;
import gravadora.gravadora.service.ArtistaService;

import java.util.List;

/**
 * Controlador responsável pelo gerenciamento de artistas no sistema.
 */
@Controller
@RequestMapping("/artistas") // Define o caminho base para este controlador
public class ArtistaController {

    @Autowired
    private ArtistaService artistaService; // Serviço para operações relacionadas a artistas

    @Autowired
    private ArtistaRepository artistaRepository; // Repositório para operações diretas no banco de dados

    /**
     * Lista todos os artistas cadastrados.
     * @param model Objeto Model usado para enviar dados para a view.
     * @return Retorna a página de listagem de artistas.
     */
    @GetMapping
    public String listarTodos(Model model) {
        List<Artista> artistas = artistaService.listarTodos(); // Busca todos os artistas
        model.addAttribute("artistas", artistas); // Adiciona a lista ao modelo
        return "listar_artista"; // Retorna a página de listagem de artistas
    }

    /**
     * Exibe o formulário de cadastro de um novo artista.
     * @param model Objeto Model para enviar dados à view.
     * @return Retorna a página de cadastro de artista.
     */
    @GetMapping("/cadastrar_artista")
    public String mostrarFormularioCadastro(Model model) {
        model.addAttribute("artista", new Artista()); // Adiciona um novo objeto artista ao modelo
        return "/cadastrar_artista"; // Retorna a página de cadastro
    }

    /**
     * Cadastra um novo artista no banco de dados.
     * @param artista Objeto Artista preenchido no formulário.
     * @return Redireciona para a listagem de artistas após o cadastro.
     */
    @PostMapping("/cadastrar_artista")
    public String cadastrarArtista(@ModelAttribute Artista artista) {
        artistaRepository.save(artista); // Salva o artista no banco de dados
        return "redirect:/artistas"; // Redireciona para a listagem de artistas
    }

    /**
     * Exibe o formulário de edição de um artista específico.
     * @param id Identificador do artista a ser editado.
     * @param model Objeto Model para enviar dados à view.
     * @return Retorna a página de edição do artista ou redireciona se o artista não for encontrado.
     */
    @GetMapping("/editar_artista/{id}")
    public String mostrarFormularioEdicao(@PathVariable Long id, Model model) {
        Artista artista = artistaService.buscarPorId(id); // Busca o artista pelo ID
        if (artista != null) {
            model.addAttribute("artista", artista); // Adiciona o artista ao modelo
            return "editar_artista"; // Retorna a página de edição
        }
        return "redirect:/artistas"; // Se não encontrar, redireciona para a listagem
    }

    /**
     * Atualiza os dados de um artista existente.
     * @param id Identificador do artista a ser atualizado.
     * @param artista Objeto Artista atualizado.
     * @return Redireciona para a listagem de artistas após a edição.
     */
    @PostMapping("/editar_artista/{id}")
    public String editarArtista(@PathVariable Long id, @ModelAttribute Artista artista) {
        artista.setId(id); // Garante que o ID do artista seja mantido
        artistaService.salvar(artista); // Salva as alterações no banco de dados
        return "redirect:/artistas"; // Redireciona para a listagem de artistas
    }

    /**
     * Exclui um artista do banco de dados.
     * @param id Identificador do artista a ser excluído.
     * @param model Objeto Model para enviar mensagens à view.
     * @return Redireciona para a listagem de artistas ou exibe erro se o artista tiver álbuns vinculados.
     */
    @GetMapping("/deletar_artista/{id}")
    public String deletarArtista(@PathVariable Long id, Model model) {
        if (artistaService.possuiAlbuns(id)) { // Verifica se o artista tem álbuns vinculados
            model.addAttribute("erro", "Não é possível excluir um artista que possui álbuns vinculados.");
            return listarTodos(model); // Retorna à listagem com a mensagem de erro
        }
        artistaService.deletar(id); // Remove o artista do banco de dados
        return "redirect:/artistas"; // Redireciona para a listagem de artistas
    }
}
