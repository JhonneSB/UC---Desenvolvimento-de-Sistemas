package gravadora.gravadora.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import gravadora.gravadora.model.Artista;
import gravadora.gravadora.service.ArtistaService;

import java.util.List;

@Controller
@RequestMapping("/artistas")
public class ArtistaController {

    @Autowired
    private ArtistaService artistaService;

    // Listar todos os artistas
    @GetMapping
    public String listarTodos(Model model) {
        List<Artista> artistas = artistaService.listarTodos();
        model.addAttribute("artistas", artistas);
        return "listar_artista"; // Página de listagem de artistas
    }

    // Exibir formulário de cadastro
    @GetMapping("/cadastrar_artista")
    public String mostrarFormularioCadastro(Model model) {
        model.addAttribute("artista", new Artista());
        return "cadastrar_artista"; // Página de cadastro de artista
    }

    // Cadastrar novo artista
    @PostMapping("/cadastrar_artista")
    public String cadastrarArtista(@ModelAttribute Artista artista) {
        artistaService.salvar(artista);
        return "redirect:/artistas";
    }
    // Exibir formulário de edição
@GetMapping("/editar_artista/{id}")
public String mostrarFormularioEdicao(@PathVariable Long id, Model model) {
    Artista artista = artistaService.buscarPorId(id); // Método para buscar artista pelo ID
    if (artista != null) {
        model.addAttribute("artista", artista);
        return "editar_artista"; // Página de edição
    }
    return "redirect:/artistas"; // Se não encontrar, redireciona para a lista
}
// Atualizar artista
@PostMapping("/editar_artista/{id}")
public String editarArtista(@PathVariable Long id, @ModelAttribute Artista artista) {
    artista.setId(id); // Garantir que o ID é mantido durante a edição
    artistaService.salvar(artista);
    return "redirect:/artistas"; // Redireciona de volta para a lista
}
// Excluir artista
@GetMapping("/deletar_artista/{id}")
public String deletarArtista(@PathVariable Long id, Model model) {
    if (artistaService.possuiAlbuns(id)) { // Verifica se o artista tem álbuns
        model.addAttribute("erro", "Não é possível excluir um artista que possui álbuns vinculados.");
        return listarTodos(model); // Retorna à listagem com a mensagem de erro
    }
    artistaService.deletar(id);
    return "redirect:/artistas";
}
}