package gravadora.gravadora.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gravadora.gravadora.model.Gravadora;
import gravadora.gravadora.repository.GravadoraRepository;

@Service
public class GravadoraService {

    @Autowired
    private GravadoraRepository gravadoraRepository;

    // Listar todas as gravadoras
    public List<Gravadora> listarTodos() {
        return gravadoraRepository.findAll();
    }

    // Buscar gravadora por ID
    public Gravadora buscarPorId(Long id) {
        return gravadoraRepository.findById(id).orElse(null);
    }

    // Salvar ou atualizar gravadora
    public void salvar(Gravadora gravadora) {
        gravadoraRepository.save(gravadora);
    }

    // Deletar gravadora
    public void deletar(Long id) {
        gravadoraRepository.deleteById(id);
    }

    // Verificar se a gravadora possui álbuns
    public boolean possuiAlbuns(Long gravadoraId) {
        Gravadora gravadora = buscarPorId(gravadoraId);
        return gravadora != null && gravadora.getAlbuns() != null && !gravadora.getAlbuns().isEmpty();
    }
}
