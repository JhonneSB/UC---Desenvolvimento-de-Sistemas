package gravadora.gravadora.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gravadora.gravadora.model.Gravadora;
import gravadora.gravadora.repository.GravadoraRepository;

@Service
public class GravadoraService {
    @Autowired
    private GravadoraRepository gravadoraRepository;

    // Método para listar todos os artistas
    public List<Gravadora> listarTodos() {
        return gravadoraRepository.findAll();
    }
}
