package gravadora.gravadora;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GravadoraApplication {

	public static void main(String[] args) {
		SpringApplication.run(GravadoraApplication.class, args);
	}

}
