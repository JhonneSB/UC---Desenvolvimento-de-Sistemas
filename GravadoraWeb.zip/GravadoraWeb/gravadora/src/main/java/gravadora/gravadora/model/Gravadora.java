package gravadora.gravadora.model;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Classe que representa uma Gravadora no sistema.
 * Cada gravadora pode possuir vários álbuns associados.
 */
@Entity // Indica que esta classe é uma entidade JPA
@Table(name = "gravadora") // Mapeia a entidade para a tabela "gravadora" no banco de dados
public class Gravadora {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) 
    private Long id; // Identificador único da gravadora (chave primária)

    private String nome; // Nome da gravadora

    /**
     * Relacionamento um-para-muitos com a entidade Album.
     * Uma gravadora pode possuir vários álbuns.
     * - mappedBy = "gravadora" indica que a entidade Album gerencia essa relação.
     * - cascade = CascadeType.ALL faz com que operações na gravadora afetem os álbuns associados.
     * - orphanRemoval = false impede que álbuns sejam removidos automaticamente ao excluir uma gravadora.
     */
    @OneToMany(mappedBy = "gravadora", cascade = CascadeType.ALL, orphanRemoval = false)
    private List<Album> albuns = new ArrayList<>();

    // Métodos Getters e Setters para acessar e modificar os atributos

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * Retorna a lista de álbuns associados à gravadora.
     * Caso a lista seja nula, inicializa uma nova lista para evitar erros.
     */
    public List<Album> getAlbuns() {
        if (albuns == null) {
            albuns = new ArrayList<>();
        }
        return albuns;
    }

    public void setAlbuns(List<Album> albuns) {
        this.albuns = albuns;
    }
}
