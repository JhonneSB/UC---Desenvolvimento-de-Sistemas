package gravadora.gravadora.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import gravadora.gravadora.model.Gravadora;

public interface GravadoraRepository extends JpaRepository<Gravadora, Long>{
    //Gravadora findByNome(String nome);  // Método para buscar artista por nome
}
