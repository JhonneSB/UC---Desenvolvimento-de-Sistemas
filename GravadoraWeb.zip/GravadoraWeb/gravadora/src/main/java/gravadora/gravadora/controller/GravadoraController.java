package gravadora.gravadora.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import gravadora.gravadora.model.Gravadora;
import gravadora.gravadora.service.GravadoraService;

import java.util.List;

@Controller
@RequestMapping("/gravadoras")
public class GravadoraController {

    @Autowired
    private GravadoraService gravadoraService;

    // Listar todas as gravadoras
    @GetMapping
    public String listarTodos(Model model) {
        List<Gravadora> gravadoras = gravadoraService.listarTodos();
        model.addAttribute("gravadoras", gravadoras);
        return "listar_gravadora"; // Página de listagem de gravadoras
    }

    // Exibir formulário de cadastro
    @GetMapping("/cadastrar_gravadora")
    public String mostrarFormularioCadastro(Model model) {
        model.addAttribute("gravadora", new Gravadora());
        return "cadastrar_gravadora"; // Página de cadastro de gravadora
    }

    // Cadastrar nova gravadora
    @PostMapping("/cadastrar_gravadora")
    public String cadastrarGravadora(@ModelAttribute Gravadora gravadora) {
        gravadoraService.salvar(gravadora);
        return "redirect:/gravadoras";
    }

    // Exibir formulário de edição
    @GetMapping("/editar_gravadora/{id}")
    public String mostrarFormularioEdicao(@PathVariable Long id, Model model) {
        Gravadora gravadora = gravadoraService.buscarPorId(id); // Método para buscar gravadora pelo ID
        if (gravadora != null) {
            model.addAttribute("gravadora", gravadora);
            return "editar_gravadora"; // Página de edição
        }
        return "redirect:/gravadoras"; // Se não encontrar, redireciona para a lista
    }

    // Atualizar gravadora
    @PostMapping("/editar_gravadora/{id}")
    public String editarGravadora(@PathVariable Long id, @ModelAttribute Gravadora gravadora) {
        gravadora.setId(id); // Garantir que o ID é mantido durante a edição
        gravadoraService.salvar(gravadora);
        return "redirect:/gravadoras"; // Redireciona de volta para a lista
    }

    // Excluir gravadora
    @GetMapping("/deletar_gravadora/{id}")
    public String deletarGravadora(@PathVariable Long id) {
        gravadoraService.deletar(id); // Método que deleta a gravadora pelo ID
        return "redirect:/gravadoras"; // Redireciona de volta para a lista
    }
}
