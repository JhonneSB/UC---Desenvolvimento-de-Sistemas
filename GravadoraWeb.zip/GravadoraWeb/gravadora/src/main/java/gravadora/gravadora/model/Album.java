package gravadora.gravadora.model;

import java.time.LocalDate;
import jakarta.persistence.*;

/**
 * Classe que representa um álbum no sistema.
 * Cada álbum pertence a uma gravadora, um artista e um gênero musical.
 */
@Entity // Define que esta classe é uma entidade JPA
@Table(name = "album") // Mapeia a entidade para a tabela "album" no banco de dados
public class Album {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Define o ID como chave primária auto-incrementada
    private Long id; 
    
    private String nome; // Nome do álbum
    private LocalDate lancamento; // Data de lançamento do álbum

    // Relacionamento com a entidade Gravadora (Muitos álbuns podem pertencer a uma única gravadora)
    @ManyToOne
    @JoinColumn(name = "gravadora_id") // Define a coluna de chave estrangeira na tabela "album"
    private Gravadora gravadora;
    
    // Relacionamento com a entidade Artista (Muitos álbuns podem pertencer a um único artista)
    @ManyToOne
    @JoinColumn(name = "artista_id")  // Define a coluna de chave estrangeira na tabela "album"
    private Artista artista;

    // Relacionamento com a entidade Gênero (Muitos álbuns podem pertencer a um único gênero musical)
    @ManyToOne
    @JoinColumn(name = "genero_id")  // Define a coluna de chave estrangeira na tabela "album"
    private Genero genero;
    
    // Métodos Getters e Setters para acessar e modificar os atributos

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public LocalDate getLancamento() {
        return lancamento;
    }

    public void setLancamento(LocalDate lancamento) {
        this.lancamento = lancamento;
    }

    public Artista getArtista() {
        return artista;
    }

    public void setArtista(Artista artista) {
        this.artista = artista;
    }

    public Gravadora getGravadora() {
        return gravadora;
    }

    public void setGravadora(Gravadora gravadora) {
        this.gravadora = gravadora;
    }

    public Genero getGenero() {
        return genero;
    }

    public void setGenero(Genero genero) {
        this.genero = genero;
    }
}
