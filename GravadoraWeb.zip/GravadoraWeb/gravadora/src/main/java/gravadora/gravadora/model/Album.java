package gravadora.gravadora.model;

import java.io.IOException;
import java.time.LocalDate;

import org.springframework.web.multipart.MultipartFile;

import jakarta.persistence.*;

@Entity
@Table(name = "album")
public class Album {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; 
    
    private String nome;
    private LocalDate lancamento;

    @ManyToOne
    @JoinColumn(name = "gravadora_id")
    private Gravadora gravadora;
    

    @ManyToOne
    @JoinColumn(name = "artista_id")  // Assumindo que o relacionamento usa 'artista_id' como coluna de chave estrangeira
    private Artista artista;

    @ManyToOne
    @JoinColumn(name = "genero_id")  // Assumindo que o relacionamento usa 'artista_id' como coluna de chave estrangeira
    private Genero genero;
    
    @Transient
    private MultipartFile imagem;

    @Lob
    @Column(name = "imagem")
    private byte[] imagemBytes;


    // Getters e Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public LocalDate getLancamento() {
        return lancamento;
    }

    public void setLancamento(LocalDate lancamento) {
        this.lancamento = lancamento;
    }

    public Artista getArtista() {
        return artista;
    }

    public void setArtista(Artista artista) {
        this.artista = artista;
    }

    public Gravadora getGravadora() {
        return gravadora;
    }

    public void setGravadora(Gravadora gravadora) {
        this.gravadora = gravadora;
    }

    // Getter e Setter para imagem
    public MultipartFile getImagem() {
        return imagem;
    }

    public void setImagem(MultipartFile imagem) {
        this.imagem = imagem;
        try {
            this.imagemBytes = imagem.getBytes();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public byte[] getImagemBytes() {
        return imagemBytes;
    }

    public void setImagemBytes(byte[] imagemBytes) {
        this.imagemBytes = imagemBytes;
    }

    public Genero getGenero() {
        return genero;
    }

    public void setGenero(Genero genero) {
        this.genero = genero;
    }
    

}