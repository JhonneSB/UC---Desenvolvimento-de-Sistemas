package gravadora.gravadora.service;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import gravadora.gravadora.model.Usuario;
import gravadora.gravadora.repository.UsuarioRepository;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository; // Agora você usa o repositório para acessar o banco de dados

    // Listar todas as gravadoras
    public List<Usuario> listarTodos() {
        return usuarioRepository.findAll(); //  busca no repositório
    }

    // Buscar gravadora por ID
    public Usuario buscarPorId(Long id) {
        return usuarioRepository.findById(id).orElse(null); // busca no repositório
    }

    // Salvar ou atualizar gravadora
    public void salvar(Usuario usuario) {
        usuarioRepository.save(usuario); // salva no repositório
    }

    // Deletar gravadora
    public void deletar(Long id) {
        usuarioRepository.deleteById(id); // deleta no repositório
    }
    // Aqui você pode fazer a busca no banco de dados ou onde for necessário
    public String buscarNomePorId(String usuarioId) {
        try {
            Long id = Long.parseLong(usuarioId); // Converte para Long, já que IDs no banco geralmente são números
            Optional<Usuario> usuario = usuarioRepository.findById(id); // Busca pelo ID

            return usuario.map(Usuario::getNome).orElse("Usuário Desconhecido"); // Retorna o nome se existir
        } catch (NumberFormatException e) {
            return "Usuário Desconhecido"; 
        }
    }
}