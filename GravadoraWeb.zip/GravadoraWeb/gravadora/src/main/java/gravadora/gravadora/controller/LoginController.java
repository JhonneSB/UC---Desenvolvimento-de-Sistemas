package gravadora.gravadora.controller;

import java.io.UnsupportedEncodingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import gravadora.gravadora.model.Usuario;
import gravadora.gravadora.repository.UsuarioRepository;
import gravadora.gravadora.service.CookieService;
import jakarta.servlet.http.HttpServletResponse;

@Controller
public class LoginController {

    @Autowired
    private UsuarioRepository usuarioRepository; // Injeta o repositório

    @GetMapping("/login")
    public String login() {
        return "login"; // Retorna a página de login
    }

    @PostMapping("/logar")
    public String loginUsuario(Usuario usuario, org.springframework.ui.Model model, HttpServletResponse response) throws UnsupportedEncodingException{
        Usuario usuarioLogado = this.usuarioRepository.findByEmailAndSenha(usuario.getEmail(), usuario.getSenha());

    if (usuarioLogado != null) {
        CookieService.setCookie(response, "usuarioId", String.valueOf(usuarioLogado.getId()), 1000);
        CookieService.setCookie(response, "nomeusuario", String.valueOf(usuarioLogado.getNome()), 1000);
        return "redirect:/"; // Redireciona para a página inicial após login bem-sucedido
    }

    model.addAttribute("Erro", "Usuário Inválido!");
    return "login"; // Retorna a página de login caso o login falhe
}



    @GetMapping("/registrar")
    public String registro() {
        return "registrar_usuario"; // Retorna a página de registro
    }

    @PostMapping("/registrar")
    public String registrar(@Validated Usuario usuario, BindingResult result) {
        if (result.hasErrors()) {
            return "registrar_usuario"; // Se houver erro, retorna à página de registro
        }

        usuarioRepository.save(usuario); // Salva no banco de dados

        return "redirect:/login"; // Redireciona para o login após registro
    }
}
