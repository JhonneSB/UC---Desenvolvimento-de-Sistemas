package gravadora.gravadora.autenticator;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class FilterConfig {

    @Bean
    public FilterRegistrationBean<AuthenticationFilter> authenticationFilter() {
        FilterRegistrationBean<AuthenticationFilter> registrationBean = new FilterRegistrationBean<>();
        registrationBean.setFilter(new AuthenticationFilter());
        registrationBean.addUrlPatterns("/home", "/artistas/cadastrar_artista", "/albuns/cadastrar", "/albuns", "/artistas", "/gravadoras", "/gravadoras/cadastrar_gravadora"); // URL que precisa de autenticação
        return registrationBean;
    }
}

