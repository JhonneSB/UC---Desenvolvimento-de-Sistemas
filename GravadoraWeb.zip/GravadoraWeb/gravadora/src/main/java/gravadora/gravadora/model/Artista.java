package gravadora.gravadora.model;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Classe que representa um artista no sistema.
 * Cada artista pode estar associado a vários álbuns e a uma gravadora.
 */
@Entity // Define que esta classe é uma entidade JPA
@Table(name = "artista") // Mapeia a entidade para a tabela "artista" no banco de dados
public class Artista {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) 
    private Long id; // Identificador único do artista (chave primária)

    private String nome; // Nome do artista

    /**
     * Relacionamento um-para-muitos com a entidade Album.
     * Um artista pode ter vários álbuns.
     * - mappedBy = "artista" indica que o mapeamento é feito pela entidade Album.
     * - cascade = CascadeType.ALL permite que operações no artista afetem seus álbuns.
     * - orphanRemoval = false evita que álbuns sejam excluídos ao remover o artista.
     */
    @OneToMany(mappedBy = "artista", cascade = CascadeType.ALL, orphanRemoval = false)
    private List<Album> albuns = new ArrayList<>(); // Inicializa a lista para evitar NullPointerException

    /**
     * Relacionamento muitos-para-um com a entidade Gravadora.
     * Vários artistas podem pertencer a uma mesma gravadora.
     */
    @ManyToOne
    @JoinColumn(name = "gravadora_id") // Define a coluna de chave estrangeira na tabela "artista"
    private Gravadora gravadora;

    // Métodos Getters e Setters para acessar e modificar os atributos

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public List<Album> getAlbuns() {
        return albuns;
    }

    public void setAlbuns(List<Album> albuns) {
        this.albuns = albuns;
    }

    /**
     * Adiciona um álbum à lista de álbuns do artista.
     * Também define a referência do artista dentro do álbum.
     */
    public void addAlbum(Album album) {
        albuns.add(album);
        album.setArtista(this);
    }

    public Gravadora getGravadora() {
        return gravadora;
    }

    public void setGravadora(Gravadora gravadora) {
        this.gravadora = gravadora;
    }

    /**
     * Método equals para comparar objetos da classe Artista.
     * Dois artistas são considerados iguais se tiverem o mesmo ID.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Artista artista = (Artista) o;
        return Objects.equals(id, artista.id);
    }

    /**
     * Método hashCode baseado no ID do artista.
     */
    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
