package gravadora.gravadora.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gravadora.gravadora.model.Genero;
import gravadora.gravadora.repository.GeneroRepository;

@Service
public class GeneroService {
    @Autowired
    private GeneroRepository generoRepository;

    // Método para listar todos os artistas
    public List<Genero> listarTodos() {
        return generoRepository.findAll();
    }
}

