package gravadora.gravadora.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import gravadora.gravadora.model.Usuario;


public interface UsuarioRepository  extends JpaRepository<Usuario, Long>{
    Usuario findByEmail(String email);
    Usuario findByEmailAndSenha(String email, String senha); // Método para buscar usuário pelo email e senha
    //Optional<Usuario> findByEmail(String email); // Novo método para buscar usuário pelo e-mail
    @Query(value = "select * from applogin.usuario where email = :email and senha = :senha", nativeQuery = true)
    
    public Usuario login (String email, String senha);
}
