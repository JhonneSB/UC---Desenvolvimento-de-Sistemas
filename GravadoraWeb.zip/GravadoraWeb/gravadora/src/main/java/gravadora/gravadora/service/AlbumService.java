package gravadora.gravadora.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import gravadora.gravadora.model.Album;
import gravadora.gravadora.repository.AlbumRepository;

@Service
public class AlbumService {

    @Autowired
    private AlbumRepository albumRepository;

    // Método para listar todos os álbuns
    public List<Album> listarTodos() {
        return albumRepository.findAll();
    }

    // Método para salvar um álbum
    public void salvar(Album album) {
        if (album.getArtista() == null) {
            throw new IllegalArgumentException("Artista não encontrado");
        }
        if (album.getGravadora() == null) {
            throw new IllegalArgumentException("Gravadora não encontrada");
        }
        if (album.getGenero() == null) {
            throw new IllegalArgumentException("Gênero não encontrado");
        }
        albumRepository.save(album);  // Salvar no banco
    }

    // Método para buscar álbuns por nome de artista
    public List<Album> buscarPorArtista(String nomeArtista) {
        return albumRepository.findByArtistaNome(nomeArtista);
    }

    // Método para buscar álbum por ID
    public Album buscarPorId(Long id) {
        return albumRepository.findById(id).orElse(null); // Retorna null se não encontrar
    }

    // Método para deletar álbum por ID
    public void deletarPorId(Long id) {
        albumRepository.deleteById(id);
    }

    // Método para atualizar um álbum
    public Album atualizar(Album album) {
        return albumRepository.save(album); // Salva ou atualiza o álbum no banco
    }
}
