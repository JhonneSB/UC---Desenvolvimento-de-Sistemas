package gravadora.gravadora.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import gravadora.gravadora.model.Album;
import gravadora.gravadora.repository.AlbumRepository;

/**
 * Classe de serviço responsável pela lógica de negócios relacionada aos álbuns.
 * Faz a intermediação entre o controlador e o repositório (banco de dados).
 */
@Service
public class AlbumService {

    // Injeta automaticamente o repositório de álbuns para acesso ao banco de dados
    @Autowired
    private AlbumRepository albumRepository;

    /**
     * Método para listar todos os álbuns cadastrados no banco de dados.
     * @return Lista de todos os álbuns.
     */
    public List<Album> listarTodos() {
        return albumRepository.findAll();
    }

    /**
     * Método para salvar um novo álbum no banco de dados.
     * Antes de salvar, verifica se o artista, gravadora e gênero estão preenchidos.
     * @param album Objeto do tipo Album a ser salvo.
     */
    public void salvar(Album album) {
        if (album.getArtista() == null) {
            throw new IllegalArgumentException("Artista não encontrado");
        }
        if (album.getGravadora() == null) {
            throw new IllegalArgumentException("Gravadora não encontrada");
        }
        if (album.getGenero() == null) {
            throw new IllegalArgumentException("Gênero não encontrado");
        }
        albumRepository.save(album);  // Salva o álbum no banco de dados
    }

    /**
     * Método para buscar álbuns por nome do artista.
     * @param nomeArtista Nome do artista cujo álbum será buscado.
     * @return Lista de álbuns que pertencem ao artista informado.
     */
    public List<Album> buscarPorArtista(String nomeArtista) {
        return albumRepository.findByArtistaNome(nomeArtista);
    }

    /**
     * Método para buscar um álbum pelo seu ID.
     * @param id ID do álbum a ser buscado.
     * @return Retorna o álbum encontrado ou null se não existir.
     */
    public Album buscarPorId(Long id) {
        return albumRepository.findById(id).orElse(null); // Retorna null se não encontrar o álbum
    }

    /**
     * Método para deletar um álbum pelo ID.
     * @param id ID do álbum a ser removido.
     */
    public void deletarPorId(Long id) {
        albumRepository.deleteById(id);  // Remove o álbum do banco de dados
    }    

    /**
     * Método para atualizar um álbum existente.
     * @param album Objeto do tipo Album com os novos dados.
     * @return O álbum atualizado.
     */
    public Album atualizar(Album album) {
        return albumRepository.save(album); // Atualiza e persiste as mudanças no banco
    }

    /**
     * Método adicional para editar um álbum.
     * Funciona de forma semelhante ao método atualizar().
     * @param album Objeto do tipo Album com os dados editados.
     */
    public void editarAlbum(Album album) {
        albumRepository.save(album); // Pode estar sobrescrevendo o artista (verificar se isso ocorre)
    }
}
