package gravadora.gravadora.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gravadora.gravadora.model.Artista;
import gravadora.gravadora.repository.ArtistaRepository;

@Service
public class ArtistaService {

    @Autowired
    private ArtistaRepository artistaRepository;

    // Método para listar todos os artistas
    public List<Artista> listarTodos() {
        return artistaRepository.findAll();
    }
}

