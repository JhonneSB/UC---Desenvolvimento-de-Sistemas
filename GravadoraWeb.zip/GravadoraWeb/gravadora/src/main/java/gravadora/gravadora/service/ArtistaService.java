package gravadora.gravadora.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import gravadora.gravadora.model.Artista; 
import gravadora.gravadora.repository.ArtistaRepository; 

@Service
public class ArtistaService {

    @Autowired
    private ArtistaRepository artistaRepository;

    // Listar todos os artistas
    public List<Artista> listarTodos() {
        return artistaRepository.findAll();
    }

    // Buscar artista por ID
    public Artista buscarPorId(Long id) {
        return artistaRepository.findById(id).orElse(null);
    }

    // Salvar ou atualizar artista
    public void salvar(Artista artista) {
        artistaRepository.save(artista);
    }

    // Deletar artista
    public void deletar(Long id) {
        artistaRepository.deleteById(id);
    }
    public boolean possuiAlbuns(Long artistaId) {
        Artista artista = buscarPorId(artistaId);
        return artista != null && artista.getAlbuns() != null && !artista.getAlbuns().isEmpty();
    }
    
}
