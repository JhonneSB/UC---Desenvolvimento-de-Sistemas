    package gravadora.gravadora.controller;

    import org.springframework.beans.factory.annotation.Autowired;
    import org.springframework.http.HttpHeaders;
    import org.springframework.http.HttpStatus;
    import org.springframework.http.MediaType;
    import org.springframework.http.ResponseEntity;
    import org.springframework.stereotype.Controller;
    import org.springframework.ui.Model;
    import org.springframework.web.bind.annotation.GetMapping;
    import org.springframework.web.bind.annotation.ModelAttribute;
    import org.springframework.web.bind.annotation.PathVariable;
    import org.springframework.web.bind.annotation.PostMapping;
    import org.springframework.web.bind.annotation.RequestMapping;
    import java.util.List;
    import gravadora.gravadora.model.Album;
    import gravadora.gravadora.model.Artista;
    import gravadora.gravadora.model.Genero;
    import gravadora.gravadora.model.Gravadora;
    import gravadora.gravadora.service.AlbumService;
    import gravadora.gravadora.service.ArtistaService;
    import gravadora.gravadora.service.GeneroService;
    import gravadora.gravadora.service.GravadoraService;

    @Controller
    @RequestMapping("/albuns")
    public class AlbumController {

    @Autowired
    private AlbumService albumService;

    @Autowired
    private ArtistaService artistaService; // Injeção da instância do ArtistaService

    @Autowired
    private GravadoraService gravadoraService;

    @Autowired
    private GeneroService generoService;


    // Listar todos os álbuns
    @GetMapping
    public String listarTodos(Model model) {
    List<Album> albuns = albumService.listarTodos();
    model.addAttribute("albuns", albuns);
    return "listar";  // Certifique-se de que a página listar.html existe
    }


    // Exibir formulário de cadastro
   @GetMapping("/cadastrar")
    public String mostrarFormularioCadastro(Model model) {
    // Buscar todos os artistas e gravadoras
    List<Artista> artistas = artistaService.listarTodos();
    List<Gravadora> gravadoras = gravadoraService.listarTodos();  // Buscar todas as gravadoras
    List<Genero> generos = generoService.listarTodos();  // Buscar todas os generos
    
    model.addAttribute("album", new Album());
    model.addAttribute("artistas", artistas);  // Adiciona a lista de artistas ao modelo
    model.addAttribute("gravadoras", gravadoras);  // Adiciona a lista de gravadoras ao modelo
    model.addAttribute("generos", generos);  // Adiciona a lista de generos ao modelo

    return "/cadastrar_album";  // Retorna a página de cadastro
    }

    @PostMapping("/cadastrar")
    public String cadastrarAlbum(@ModelAttribute Album album) {
    try {
        albumService.salvar(album);  // Chama o método de salvar
        return "redirect:/albuns";  // Redireciona para a lista de álbuns após cadastro
    } catch (Exception e) {
        e.printStackTrace();  // Exibe a stack trace no console
        return "erro";  // Retorna uma página de erro personalizada
    }
    }

    // Buscar álbuns por artista
    @GetMapping("/artista/{nome}")
    public String buscarPorArtista(@PathVariable String nome, Model model) {
        List<Album> albuns = albumService.buscarPorArtista(nome);
        model.addAttribute("albuns", albuns); // Adiciona os álbuns encontrados ao modelo
        return "listar"; // Retorna a página de listagem
    }

    // Exibir imagem do álbum
    @GetMapping("/album/imagem/{id}")
    public ResponseEntity<byte[]> obterImagemAlbum(@PathVariable Long id) {
    Album album = albumService.buscarPorId(id);
    
    if (album == null || album.getImagemBytes() == null) {
        return ResponseEntity.notFound().build(); // Retorna erro 404 se não houver imagem
    }

    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.IMAGE_JPEG); // Altere para IMAGE_PNG se necessário

    return new ResponseEntity<>(album.getImagemBytes(), headers, HttpStatus.OK);
    }


    // Deletar álbum
    @PostMapping("/deletar/{id}")
    public String deletarAlbum(@PathVariable Long id) {
        albumService.deletarPorId(id); // Método no serviço para deletar o álbum
        return "redirect:/albuns"; // Redireciona para a lista de álbuns
     }

    // Editar álbum
    @GetMapping("/editar/{id}")
    public String mostrarFormularioEdicao(@PathVariable Long id, Model model) {
    Album album = albumService.buscarPorId(id);
    List<Genero> generos = generoService.listarTodos(); // Busca todos os gêneros
    List<Gravadora> gravadoras = gravadoraService.listarTodos(); // Busca todos os gêneros

    if (album != null) {
        model.addAttribute("album", album);
        model.addAttribute("generos", generos); // Adiciona a lista de gêneros ao modelo
        model.addAttribute("gravadoras", gravadoras); // Adiciona a lista de gravadoras ao modelo
        return "editar_album";
    } else {
        return "redirect:/albuns";
    }
}


    // Atualizar álbum
    @PostMapping("/editar")
    public String editarAlbum(@ModelAttribute Album album) {
    // Apenas atualiza o nome e o gênero
    Album albumExistente = albumService.buscarPorId(album.getId());
    if (albumExistente != null) {
        albumExistente.setNome(album.getNome()); // Atualiza o nome
        albumExistente.setGenero(album.getGenero()); // Atualiza o gênero
        albumExistente.setGravadora(album.getGravadora()); // Atualiza o gênero
        albumService.salvar(albumExistente); // Salva as alterações no banco
    }
        return "redirect:/albuns"; // Redireciona para a lista de álbuns
}
}