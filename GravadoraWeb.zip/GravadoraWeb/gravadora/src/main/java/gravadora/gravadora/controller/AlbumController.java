package gravadora.gravadora.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import java.util.List;
import gravadora.gravadora.model.Album;
import gravadora.gravadora.model.Artista;
import gravadora.gravadora.model.Genero;
import gravadora.gravadora.model.Gravadora;
import gravadora.gravadora.service.AlbumService;
import gravadora.gravadora.service.ArtistaService;
import gravadora.gravadora.service.GeneroService;
import gravadora.gravadora.service.GravadoraService;

/**
 * Controlador responsável pelo gerenciamento dos álbuns.
 */
@Controller
@RequestMapping("/albuns") // Define a rota base para este controlador
public class AlbumController {

    @Autowired
    private AlbumService albumService;

    @Autowired
    private ArtistaService artistaService; // Serviço para gerenciar artistas

    @Autowired
    private GravadoraService gravadoraService; // Serviço para gerenciar gravadoras

    @Autowired
    private GeneroService generoService; // Serviço para gerenciar gêneros musicais

    /**
     * Lista todos os álbuns disponíveis.
     * @param model Objeto Model para passar informações para a view.
     * @return Retorna a página de listagem de álbuns.
     */
    @GetMapping
    public String listarTodos(Model model) {
        List<Album> albuns = albumService.listarTodos(); // Obtém todos os álbuns do banco
        model.addAttribute("albuns", albuns); // Adiciona a lista ao modelo
        return "listar";  // Retorna a página listar.html
    }

    /**
     * Exibe o formulário de cadastro de um novo álbum.
     * @param model Objeto Model para passar informações para a view.
     * @return Retorna a página de cadastro do álbum.
     */
    @GetMapping("/cadastrar")
    public String mostrarFormularioCadastro(Model model) {
        // Buscar todos os artistas, gravadoras e gêneros para preencher os selects
        List<Artista> artistas = artistaService.listarTodos();
        List<Gravadora> gravadoras = gravadoraService.listarTodos();
        List<Genero> generos = generoService.listarTodos();
        
        // Adicionar listas ao modelo
        model.addAttribute("album", new Album());
        model.addAttribute("artistas", artistas); 
        model.addAttribute("gravadoras", gravadoras);
        model.addAttribute("generos", generos);
    
        // Se faltar dados essenciais, exibe uma mensagem de erro
        if (artistas.isEmpty() || gravadoras.isEmpty() || generos.isEmpty()) {
            model.addAttribute("erro", "Não há dados suficientes para cadastrar um álbum.");
        }
    
        return "/cadastrar_album";  // Retorna a página de cadastro
    }

    /**
     * Cadastra um novo álbum no sistema.
     * @param album Objeto Album preenchido no formulário.
     * @param model Objeto Model para passar informações para a view.
     * @return Redireciona para a listagem de álbuns ou retorna erro.
     */
    @PostMapping("/cadastrar")
    public String cadastrarAlbum(@ModelAttribute Album album, Model model) {
        try {
            // Verifica se os campos obrigatórios foram preenchidos
            if (album.getArtista() == null || album.getGravadora() == null || album.getGenero() == null) {
                model.addAttribute("erro", "Todos os campos obrigatórios devem ser preenchidos.");
                return "/cadastrar_album";
            }

            albumService.salvar(album);  // Salva o álbum no banco de dados
            return "redirect:/albuns";  // Redireciona para a lista de álbuns
        } catch (Exception e) {
            e.printStackTrace();  // Imprime o erro no console para depuração
            model.addAttribute("erro", "Ocorreu um erro ao cadastrar o álbum. Tente novamente.");
            return "/cadastrar_album";  // Retorna para a página de cadastro com a mensagem de erro
        }
    }

    /**
     * Busca álbuns de um artista específico pelo nome.
     * @param nome Nome do artista.
     * @param model Objeto Model para passar informações para a view.
     * @return Retorna a página de listagem dos álbuns do artista.
     */
    @GetMapping("/artista/{nome}")
    public String buscarPorArtista(@PathVariable String nome, Model model) {
        List<Album> albuns = albumService.buscarPorArtista(nome);
        model.addAttribute("albuns", albuns); // Adiciona a lista ao modelo
        return "listar"; // Retorna a página de listagem
    }

    /**
     * Deleta um álbum pelo ID.
     * @param id Identificador do álbum a ser deletado.
     * @return Redireciona para a listagem de álbuns.
     */
    @PostMapping("/deletar/{id}")
    public String deletarAlbum(@PathVariable Long id) {
        try {
            albumService.deletarPorId(id);  // Chama o serviço para deletar o álbum
        } catch (Exception e) {
            e.printStackTrace();  // Caso ocorra erro, exibe no console
            return "redirect:/albuns";  // Redireciona para a lista de álbuns
        }
        return "redirect:/albuns"; // Redireciona para a lista de álbuns
    }

    /**
     * Exibe o formulário de edição de um álbum.
     * @param id Identificador do álbum a ser editado.
     * @param model Objeto Model para passar informações para a view.
     * @return Retorna a página de edição do álbum.
     */
    @GetMapping("/editar/{id}")
    public String mostrarFormularioEdicao(@PathVariable Long id, Model model) {
        Album album = albumService.buscarPorId(id); // Busca o álbum pelo ID
        if (album == null) {
            return "redirect:/albuns";  // Se não existir, redireciona para a lista
        }

        // Busca gêneros e gravadoras para preencher os selects na edição
        List<Genero> generos = generoService.listarTodos();
        List<Gravadora> gravadoras = gravadoraService.listarTodos();

        model.addAttribute("album", album);
        model.addAttribute("generos", generos); 
        model.addAttribute("gravadoras", gravadoras);

        return "editar_album"; // Retorna a página de edição
    }

    /**
     * Atualiza os dados de um álbum existente.
     * @param album Objeto Album atualizado.
     * @return Redireciona para a listagem de álbuns.
     */
    @PostMapping("/editar")
    public String editarAlbum(@ModelAttribute Album album) {
        Album albumExistente = albumService.buscarPorId(album.getId()); // Busca o álbum original pelo ID
        if (albumExistente != null) {
            // Atualiza os dados do álbum
            albumExistente.setNome(album.getNome());
            albumExistente.setGenero(album.getGenero());
            albumExistente.setGravadora(album.getGravadora());
            albumService.salvar(albumExistente);  // Salva as alterações no banco de dados
        }
        return "redirect:/albuns";  // Redireciona para a lista de álbuns
    }
}
