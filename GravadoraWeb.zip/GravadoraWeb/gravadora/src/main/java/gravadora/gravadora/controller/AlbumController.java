    package gravadora.gravadora.controller;

    import org.springframework.beans.factory.annotation.Autowired;
    import org.springframework.stereotype.Controller;
    import org.springframework.ui.Model;
    import org.springframework.web.bind.annotation.GetMapping;
    import org.springframework.web.bind.annotation.ModelAttribute;
    import org.springframework.web.bind.annotation.PathVariable;
    import org.springframework.web.bind.annotation.PostMapping;
    import org.springframework.web.bind.annotation.RequestMapping;
    import java.util.List;
    import gravadora.gravadora.model.Album;
    import gravadora.gravadora.model.Artista;
    import gravadora.gravadora.model.Genero;
    import gravadora.gravadora.model.Gravadora;
    import gravadora.gravadora.service.AlbumService;
    import gravadora.gravadora.service.ArtistaService;
    import gravadora.gravadora.service.GeneroService;
    import gravadora.gravadora.service.GravadoraService;

    @Controller
    @RequestMapping("/albuns")
    public class AlbumController {

    @Autowired
    private AlbumService albumService;

    @Autowired
    private ArtistaService artistaService; // Injeção da instância do ArtistaService

    @Autowired
    private GravadoraService gravadoraService;

    @Autowired
    private GeneroService generoService;


    // Listar todos os álbuns
    @GetMapping
    public String listarTodos(Model model) {
    List<Album> albuns = albumService.listarTodos();
    model.addAttribute("albuns", albuns);
    return "listar";  // Certifique-se de que a página listar.html existe
    }


    // Exibir formulário de cadastro
    @GetMapping("/cadastrar")
    public String mostrarFormularioCadastro(Model model) {
        // Buscar todos os artistas, gravadoras e gêneros
        List<Artista> artistas = artistaService.listarTodos();
        List<Gravadora> gravadoras = gravadoraService.listarTodos();
        List<Genero> generos = generoService.listarTodos();
        
        // Adicionar listas ao modelo
        model.addAttribute("album", new Album());
        model.addAttribute("artistas", artistas); 
        model.addAttribute("gravadoras", gravadoras);
        model.addAttribute("generos", generos);
    
        // Verifica se alguma lista está vazia e pode exibir uma mensagem ou lidar de outra forma
        if (artistas.isEmpty() || gravadoras.isEmpty() || generos.isEmpty()) {
            model.addAttribute("erro", "Não há dados suficientes para cadastrar um álbum.");
        }
    
        return "/cadastrar_album";  // Retorna a página de cadastro
    }
    

    @PostMapping("/cadastrar")
    public String cadastrarAlbum(@ModelAttribute Album album, Model model) {
        try {
            if (album.getArtista() == null || album.getGravadora() == null || album.getGenero() == null) {
                model.addAttribute("erro", "Todos os campos obrigatórios devem ser preenchidos.");
                return "/cadastrar_album";
            }
    
            albumService.salvar(album);  // Chama o método de salvar no serviço
            return "redirect:/albuns";  // Redireciona para a lista de álbuns após cadastro
        } catch (Exception e) {
            e.printStackTrace();  // Exibe a stack trace no console
            model.addAttribute("erro", "Ocorreu um erro ao cadastrar o álbum. Tente novamente.");
            return "/cadastrar_album";  // Retorna para a página de cadastro com a mensagem de erro
        }
    }
    
    

    // Buscar álbuns por artista
    @GetMapping("/artista/{nome}")
    public String buscarPorArtista(@PathVariable String nome, Model model) {
        List<Album> albuns = albumService.buscarPorArtista(nome);
        model.addAttribute("albuns", albuns); // Adiciona os álbuns encontrados ao modelo
        return "listar"; // Retorna a página de listagem
    }

    // Deletar álbum
    @PostMapping("/deletar/{id}")
    public String deletarAlbum(@PathVariable Long id) {
        albumService.deletarPorId(id); // Método no serviço para deletar o álbum
        return "redirect:/albuns"; // Redireciona para a lista de álbuns
     }

    // Editar álbum
    @GetMapping("/editar/{id}")
    public String mostrarFormularioEdicao(@PathVariable Long id, Model model) {
        Album album = albumService.buscarPorId(id);
        if (album == null) {
            return "redirect:/albuns";  // Se o álbum não for encontrado, redireciona para a lista de álbuns
        }
    
        List<Genero> generos = generoService.listarTodos();
        List<Gravadora> gravadoras = gravadoraService.listarTodos();
    
        model.addAttribute("album", album);
        model.addAttribute("generos", generos); 
        model.addAttribute("gravadoras", gravadoras);
    
        return "editar_album";
    }
    


    // Atualizar álbum
    @PostMapping("/editar")
    public String editarAlbum(@ModelAttribute Album album) {
        Album albumExistente = albumService.buscarPorId(album.getId());
        if (albumExistente != null) {
            albumExistente.setNome(album.getNome());
            albumExistente.setGenero(album.getGenero());
            albumExistente.setGravadora(album.getGravadora());
            albumService.salvar(albumExistente);  // Salva as alterações no banco de dados
        }
        return "redirect:/albuns";  // Redireciona para a lista de álbuns
    }
    }    