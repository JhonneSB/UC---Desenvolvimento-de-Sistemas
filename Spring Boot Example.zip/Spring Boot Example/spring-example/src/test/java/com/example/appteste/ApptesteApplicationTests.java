package com.example.appteste;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApptesteApplicationTests {

	@Test
	void contextLoads() {
	}

}
